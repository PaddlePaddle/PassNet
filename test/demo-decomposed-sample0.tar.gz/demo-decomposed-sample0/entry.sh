#!/bin/bash

export PYTHONPATH=$(pwd):$PYTHONPATH
SAMPLE_ROOT=$(python3 -c "import graph_net_bench; import os; print(os.path.dirname(os.path.dirname(graph_net_bench.__file__)))")
OUTPUT_PATH=$SCRATCH/workspace_graph_net_bench_test

mkdir -p "$OUTPUT_PATH"

# NOTE: `graphs/` contains decomposed graphs where `model.py` lives in deep subgraph dirs
# (e.g. `graphs/<model>/_decomposed/.../_decomposed/<subgraph>/model.py`).
# The prefix-mode runner only executes entries whose directory directly contains `model.py`,
# so we generate an allow-list of those directories dynamically.
model_list="$OUTPUT_PATH/allow_list_model_dirs.txt"
python3 - <<EOF
import sys
from pathlib import Path

sample_root = Path(r"$SAMPLE_ROOT")
graphs_root = sample_root / "graphs"
out_path = Path(r"$model_list")

if not graphs_root.is_dir():
    raise SystemExit(f"graphs directory not found: {graphs_root}")

model_dirs = sorted({str(p.parent.relative_to(sample_root)) for p in graphs_root.rglob("model.py")})
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text("\n".join(model_dirs) + ("\n" if model_dirs else ""))
print(f"Generated allow-list with {len(model_dirs)} entries: {out_path}", file=sys.stderr, flush=True)
EOF

python3 -m graph_net_bench.torch.test_compiler \
    --model-path-prefix $SAMPLE_ROOT \
    --allow-list $model_list \
    --compiler pass_mgr \
    --device cuda \
    --config $(base64 -w 0 <<EOF
{
    "input_pass_rule_dir": "$SAMPLE_ROOT/input_pass_rule_dir",
    "output_pass_rule_dir": "$SAMPLE_ROOT/output_pass_rule_dir",
    "output_pass_pattern_limit": 100,
    "output_pass_replacement_func_limit": 1
}
EOF
) 2>&1 | tee "$OUTPUT_PATH/validation.log"

python3 -m graph_net_bench.aggregate_es_scores \
    --benchmark-path "$OUTPUT_PATH/validation.log" \
    --sample-id 1 \
    --output-json-file-path "$OUTPUT_PATH/aggregated_score.json"
