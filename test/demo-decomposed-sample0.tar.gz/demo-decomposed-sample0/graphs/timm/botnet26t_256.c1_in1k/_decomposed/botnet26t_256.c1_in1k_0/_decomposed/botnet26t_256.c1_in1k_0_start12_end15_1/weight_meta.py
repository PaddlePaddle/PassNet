class Program_weight_tensor_meta_tmp_14:
	name = "in_0"
	original_name = "tmp_14"
	shape = [4, 256, 64]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_tmp_18:
	name = "in_1"
	original_name = "tmp_18"
	shape = [4, 256, 256]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_w_5:
	name = "w_0"
	original_name = "w_5"
	shape = [31, 64]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.004
	std = 0.005
