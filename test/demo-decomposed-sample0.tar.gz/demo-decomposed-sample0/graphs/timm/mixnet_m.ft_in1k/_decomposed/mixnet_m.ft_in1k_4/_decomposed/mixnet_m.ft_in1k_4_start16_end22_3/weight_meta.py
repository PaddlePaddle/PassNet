class Program_weight_tensor_meta_tmp_30:
	name = "in_0"
	original_name = "tmp_30"
	shape = [1, 1200, 7, 7]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_tmp_33:
	name = "in_1"
	original_name = "tmp_33"
	shape = [1, 100, 1, 1]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_w_14:
	name = "w_0"
	original_name = "w_14"
	shape = [1200]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = 0.000
	std = 0.000


class Program_weight_tensor_meta_w_15:
	name = "w_1"
	original_name = "w_15"
	shape = [1200, 100, 1, 1]
	dtype = "torch.float32"
	device = "cuda:0"
	mean = -0.000
	std = 0.002
