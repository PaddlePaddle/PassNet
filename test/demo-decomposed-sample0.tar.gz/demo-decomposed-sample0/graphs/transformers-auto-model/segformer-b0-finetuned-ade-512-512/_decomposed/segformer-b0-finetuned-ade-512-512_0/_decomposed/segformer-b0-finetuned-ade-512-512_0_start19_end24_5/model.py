import torch

class GraphModule(torch.nn.Module):

    def forward(self, in_0, w_0, w_1):
        tmp_0 = torch.nn.functional.linear(in_0, w_1, w_0)
        tmp_1 = tmp_0.view(1, -1, 2, 32)
        tmp_0 = None
        tmp_2 = tmp_1.transpose(1, 2)
        tmp_1 = None
        tmp_3 = in_0.permute(0, 2, 1)
        tmp_4 = tmp_3.reshape(1, 64, 64, 64)
        tmp_3 = None
        return (tmp_2, tmp_4)