import torch

class GraphModule(torch.nn.Module):

    def forward(self, in_0, in_1, in_2, w_0, w_1):
        tmp_0 = torch.nn.functional.linear(in_0, w_1, w_0)
        tmp_1 = in_2.view(1, 13, -1, 64)
        tmp_2 = tmp_1.transpose(1, 2)
        tmp_1 = None
        tmp_3 = tmp_0.view(1, 13, -1, 64)
        tmp_0 = None
        tmp_4 = tmp_3.transpose(1, 2)
        tmp_3 = None
        tmp_5 = in_1.view(1, 13, 16, 64)
        tmp_6 = tmp_5.transpose(1, 2)
        tmp_5 = None
        tmp_7 = tmp_6.reshape(16, -1, 64)
        tmp_6 = None
        tmp_8 = tmp_2.reshape(16, -1, 64)
        tmp_9 = tmp_4.reshape(16, -1, 64)
        tmp_10 = tmp_8.transpose(1, 2)
        tmp_8 = None
        return (tmp_4, tmp_7, tmp_9, tmp_10, tmp_2)