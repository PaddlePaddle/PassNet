class Program_weight_tensor_meta_L_self_modules_stem_modules_0_parameters_weight_:
    name = "L_self_modules_stem_modules_0_parameters_weight_"
    shape = [128, 3, 4, 4]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stem_modules_0_parameters_bias_:
    name = "L_self_modules_stem_modules_0_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_s1:
    name = "s1"
    shape = []
    dtype = "torch.int64"
    device = "cpu"
    mean = None
    std = None
    data = [4]


class Program_weight_tensor_meta_L_x_:
    name = "L_x_"
    shape = [1, 3, 224, 224]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.222
    std = 1.285
    data = None


class Program_weight_tensor_meta_L_self_modules_stem_modules_1_parameters_weight_:
    name = "L_self_modules_stem_modules_1_parameters_weight_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stem_modules_1_parameters_bias_:
    name = "L_self_modules_stem_modules_1_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_conv_dw_parameters_weight_"
    shape = [128, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_conv_dw_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_norm_parameters_weight_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_norm_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_weight_"
    shape = [512, 128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_weight_"
    shape = [128, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_conv_dw_parameters_weight_"
    shape = [128, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_conv_dw_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_norm_parameters_weight_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_norm_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_weight_"
    shape = [512, 128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_weight_"
    shape = [128, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_conv_dw_parameters_weight_"
    shape = [128, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_conv_dw_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_norm_parameters_weight_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_norm_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_weight_"
    shape = [512, 128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_weight_"
    shape = [128, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_0_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_bias_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_downsample_modules_0_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_downsample_modules_0_parameters_weight_"
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_downsample_modules_0_parameters_bias_:
    name = (
        "L_self_modules_stages_modules_1_modules_downsample_modules_0_parameters_bias_"
    )
    shape = [128]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_downsample_modules_1_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_downsample_modules_1_parameters_weight_"
    shape = [256, 128, 2, 2]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_downsample_modules_1_parameters_bias_:
    name = (
        "L_self_modules_stages_modules_1_modules_downsample_modules_1_parameters_bias_"
    )
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_conv_dw_parameters_weight_"
    shape = [256, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_conv_dw_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_norm_parameters_weight_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_norm_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_weight_"
    shape = [1024, 256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_weight_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_weight_"
    shape = [256, 1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_conv_dw_parameters_weight_"
    shape = [256, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_conv_dw_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_norm_parameters_weight_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_norm_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_weight_"
    shape = [1024, 256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_weight_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_weight_"
    shape = [256, 1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_conv_dw_parameters_weight_"
    shape = [256, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.001
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_conv_dw_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_norm_parameters_weight_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_norm_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_weight_"
    shape = [1024, 256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_weight_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_weight_"
    shape = [256, 1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_1_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_bias_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_downsample_modules_0_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_downsample_modules_0_parameters_weight_"
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_downsample_modules_0_parameters_bias_:
    name = (
        "L_self_modules_stages_modules_2_modules_downsample_modules_0_parameters_bias_"
    )
    shape = [256]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_downsample_modules_1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_downsample_modules_1_parameters_weight_"
    shape = [512, 256, 2, 2]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_downsample_modules_1_parameters_bias_:
    name = (
        "L_self_modules_stages_modules_2_modules_downsample_modules_1_parameters_bias_"
    )
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_3_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_4_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_5_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_6_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_7_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_8_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_9_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_10_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_11_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_12_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_13_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_14_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_15_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_16_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_17_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_18_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_19_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_20_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_21_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_22_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_23_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_24_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_25_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_conv_dw_parameters_weight_"
    shape = [512, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_conv_dw_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_norm_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_norm_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_fc1_parameters_weight_"
    shape = [2048, 512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_fc1_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_grn_parameters_bias_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_grn_parameters_weight_"
    shape = [2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_fc2_parameters_weight_"
    shape = [512, 2048]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_2_modules_blocks_modules_26_modules_mlp_modules_fc2_parameters_bias_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_downsample_modules_0_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_downsample_modules_0_parameters_weight_"
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_downsample_modules_0_parameters_bias_:
    name = (
        "L_self_modules_stages_modules_3_modules_downsample_modules_0_parameters_bias_"
    )
    shape = [512]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_downsample_modules_1_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_downsample_modules_1_parameters_weight_"
    shape = [1024, 512, 2, 2]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_downsample_modules_1_parameters_bias_:
    name = (
        "L_self_modules_stages_modules_3_modules_downsample_modules_1_parameters_bias_"
    )
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_conv_dw_parameters_weight_"
    shape = [1024, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_conv_dw_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_norm_parameters_weight_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_norm_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_weight_"
    shape = [4096, 1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_fc1_parameters_bias_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_bias_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_grn_parameters_weight_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_weight_"
    shape = [1024, 4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_0_modules_mlp_modules_fc2_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_conv_dw_parameters_weight_"
    shape = [1024, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_conv_dw_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_norm_parameters_weight_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_norm_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_weight_"
    shape = [4096, 1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_fc1_parameters_bias_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_bias_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_grn_parameters_weight_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_weight_"
    shape = [1024, 4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_1_modules_mlp_modules_fc2_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_conv_dw_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_conv_dw_parameters_weight_"
    shape = [1024, 1, 7, 7]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_conv_dw_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_conv_dw_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_norm_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_norm_parameters_weight_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_norm_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_norm_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_weight_"
    shape = [4096, 1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_fc1_parameters_bias_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_bias_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_grn_parameters_weight_"
    shape = [4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_weight_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_weight_"
    shape = [1024, 4096]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = -0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_bias_:
    name = "L_self_modules_stages_modules_3_modules_blocks_modules_2_modules_mlp_modules_fc2_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_head_modules_norm_parameters_weight_:
    name = "L_self_modules_head_modules_norm_parameters_weight_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 1.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_head_modules_norm_parameters_bias_:
    name = "L_self_modules_head_modules_norm_parameters_bias_"
    shape = [1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None


class Program_weight_tensor_meta_L_self_modules_head_modules_fc_parameters_weight_:
    name = "L_self_modules_head_modules_fc_parameters_weight_"
    shape = [1000, 1024]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.020
    data = None


class Program_weight_tensor_meta_L_self_modules_head_modules_fc_parameters_bias_:
    name = "L_self_modules_head_modules_fc_parameters_bias_"
    shape = [1000]
    dtype = "torch.float32"
    device = "cuda:0"
    mean = 0.000
    std = 0.000
    data = None
